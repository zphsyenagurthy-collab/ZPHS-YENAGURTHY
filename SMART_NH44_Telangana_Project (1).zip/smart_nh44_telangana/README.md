# SMART NH-44 Telangana

A mobile-friendly, single-page highway traveller information portal.

## Files
- `index.html` — complete website; no build tools or installation required.
- `SOURCES_AND_VERIFICATION.txt` — source notes and important limitations.

## Preview locally
Open `index.html` in Chrome, Edge, Firefox or a mobile browser. Internet is needed for Google Maps links.

## Publish it free (recommended: GitHub Pages)
1. Sign in to GitHub and create a new public repository named `smart-nh44-telangana`.
2. Upload `index.html` to the repository root.
3. Open Settings → Pages.
4. Under Build and deployment, select Deploy from a branch, choose `main` and `/ (root)`, then Save.
5. GitHub will publish a URL similar to `https://YOUR-USERNAME.github.io/smart-nh44-telangana/`.
6. Open that URL on a phone and test every link.
7. Generate ONE QR code using the final published URL. Print it on your boards. If you update the website later, keep the same URL so the QR code continues to work.

Do not print a QR code containing a temporary preview URL or a computer-local file path.

## Important
This is an independent student/community information project, not an official NHAI or government service. The starter directory includes map/business listings, not a complete audited inventory. Confirm exact location, phone number, opening status, toilets, fuel, charging and accessibility with each facility before advertising those amenities. Emergency contact availability and service coverage should be confirmed locally. Do not claim real-time accident alerts unless you integrate an authorised live data source.

## Updating the data
Open `index.html` in a text editor. Edit the `facilities` and `safety` arrays near the bottom of the file. For each entry, verify its exact branch and details before adding it. Keep source and last-verified date in your project records.
